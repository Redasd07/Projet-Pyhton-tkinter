from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
import sqlite3



class SignUp:
    def __init__(self, root):
        self.window = root
        self.window.title("Sign Up")
        self.window.geometry("1100x700+0+0")
        self.window.config(bg="grey95")


        # ==============================DESIGN PART===================================

        self.frame1 = Frame(self.window)
        self.frame1.place(x=0, y=0, relwidth=0.6, relheight=1)
        image = Image.open("Gérer.png")
        image = image.resize((450, 700), Image.ANTIALIAS)
        image = ImageTk.PhotoImage(image)
        label1 = Label(self.frame1, image=image)
        label1.image = image
        label1.place(x=0, y=0)

        self.frame2 = Frame(self.window, bg="#BEB1E4")
        self.frame2.place(x=450, y=0, relwidth=1, relheight=1)

        frame = Frame(self.window, bg="white")
        frame.place(x=520,y=50,width=500,height=620)

        title1 = Label(frame, text="Inscription", font=("times new roman",25,"bold"),bg="white").place(x=170, y=10)
        Prenom = Label(frame, text="Prénom", font=("helvetica",15,"bold"),bg="white").place(x=20, y=100)
        Nom = Label(frame, text="Nom", font=("helvetica",15,"bold"),bg="white").place(x=240, y=100)

        self.Prenom_txt = Entry(frame,bg='lightyellow',font=("arial"))
        self.Prenom_txt.place(x=20, y=130, width=200)

        self.Nom_txt = Entry(frame,bg='lightyellow',font=("arial"))
        self.Nom_txt.place(x=240, y=130, width=200)

        email = Label(frame, text="Email", font=("helvetica",15,"bold"),bg="white").place(x=20, y=180)

        self.email_txt = Entry(frame,bg='lightyellow',font=("arial"))
        self.email_txt.place(x=20, y=210, width=420)

        password =  Label(frame, text="Mot de Passe", font=("helvetica",15,"bold"),bg="white").place(x=20, y=250)

        self.password_txt = Entry(frame ,bg='lightyellow',font=("arial"),show="*")
        self.password_txt.place(x=20, y=290, width=420)

        self.terms = IntVar()
        terms_and_con = Checkbutton(frame,text="J'accepte les Termes D'utilisation ",variable=self.terms,onvalue=1,offvalue=0,bg="white",font=("times new roman",12)).place(x=20,y=340)
        self.signup = Button(frame,text="S'inscrire",command=self.signup_func,font=("helvetica",20),bg="#2196f3",fg="white",cursor="hand2").place(x=120,y=380,width=250)
        Connexion = Label(frame, text="Vous avez déja un Compte?", font=("helvetica",12,"bold"),bg="white").place(x=20, y=450)
        login_btn = Button(frame, text="Se Connecter", command=self.redirect_to_login, font=("helvetica", 20,),bg="#2196f3",fg="white",cursor="hand2",).place(x=120, y=500,width=250)


    def redirect_to_login(self):
        from Login import login_page
        self.window.destroy()
        root = Tk()
        obj = login_page(root)
        root.mainloop()


    def signup_func(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        if self.Prenom_txt.get()=="" or self.Nom_txt.get() == "" or self.email_txt.get() == "" or self.password_txt.get()== "":
            messagebox.showerror("Erreur!","Tous les champs doivent être rempli!",parent=self.window)

        elif self.terms.get() == 0:
            messagebox.showerror("Error!","Merci de bien vouloir Accepter nos Termes et Conditions",parent=self.window)

        else:
            try:
                cur.execute("select * from admin where Email=?", (self.email_txt.get(),))
                row = cur.fetchone()
                print(row)
                # Check if th entered email id is already exists or not.
                if row != None:
                    messagebox.showerror("Error!","Email déjà utilisé, Choisissez un autre",parent=self.window)
                else:

                    cur.execute("insert into admin (Prenom,Nom,Email,Password) values(?,?,?,?)",
                                    (
                                        self.Prenom_txt.get(),
                                        self.Nom_txt.get(),
                                        self.email_txt.get(),
                                        self.password_txt.get()
                                    ))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Bienvenue Parmi Nous !",parent=self.window)
                    self.reset_fields()
            except Exception as es:
                messagebox.showerror("Erreur!",f"Erreur due à {es}",parent=self.window)


    def reset_fields(self):
        self.Prenom_txt.delete(0, END)
        self.Nom_txt.delete(0, END)
        self.email_txt.delete(0, END)
        self.password_txt.delete(0, END)

if __name__ == "__main__":
    root = Tk()
    obj = SignUp(root)
    root.mainloop()
