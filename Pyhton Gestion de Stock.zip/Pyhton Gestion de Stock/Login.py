from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3
from SignUp import SignUp
from dashboard import Interface


class login_page:
    def __init__(self, root):
        self.window = root
        self.window.title("Log In")
        self.window.geometry("1100x700+0+0")
        self.window.config(bg="white")

        # ==============================DESIGN PART===================================

        self.frame1 = Frame(self.window)
        self.frame1.place(x=0, y=0, relwidth=0.6, relheight=1)

        image = Image.open("Gérer.png")
        image = image.resize((450, 700), Image.ANTIALIAS)
        image = ImageTk.PhotoImage(image)
        label1 = Label(self.frame1, image=image)
        label1.image = image
        label1.place(x=0, y=0)

        # =============Entry Field & Buttons============

        self.frame2 = Frame(self.window, bg="#BEB1E4")
        self.frame2.place(x=450, y=0, relwidth=1, relheight=1)

        self.frame3 = Frame(self.frame2, bg="white")
        self.frame3.place(x=80, y=100, width=500, height=550)

        self.email_label = Label(self.frame3, text="Connexion ", font=("helvetica", 25, "bold"), bg="white",fg="black").place(x=170, y=20)
        self.email_label = Label(self.frame3, text="Email ", font=("helvetica", 20, "bold"), bg="white",fg="black").place(x=50, y=110)
        self.email_entry = Entry(self.frame3, font=("goudy old style",15),bg='lightyellow')
        self.email_entry.place(x=50, y=150, width=420)

        self.password_label = Label(self.frame3, text="Mot de Passe ", font=("helvetica", 20, "bold"), bg="white",fg="black").place(x=50, y=190)
        self.password_entry = Entry(self.frame3, font=("goudy old style",15),show="*",bg='lightyellow')
        self.password_entry.place(x=50, y=230, width=420)

        # ================Buttons===================
        self.login_button = Button(self.frame3, text="Se Connecter", command=self.login_func,font=("goudy old style",20),bg="#2196f3",fg="white",cursor="hand2").place(x=50, y=290, width=420)
        self.create_button = Label(self.frame3, text="Vous n'avez pas de Compte ? ", font=("helvetica", 15, "bold"), bg="white",fg="black").place(x=50, y=370)
        self.create_button = Button(self.frame3, text="Créez un Compte", command=self.redirect_window, font=("goudy old style",20),bg="#2196f3",fg="white",cursor="hand2").place(x=140, y=420, width=250)

    def login_func(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        if self.email_entry.get() == "" or self.password_entry.get() == "":
            messagebox.showerror("Erreur!", "Tous les champs sont obligatoires", parent=self.window)
        else:
            try:

                cur.execute("select * from admin where Email=? and Password=?",(self.email_entry.get(), self.password_entry.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Erreur!", "Email ou Password Erronés", parent=self.window)
                else:
                    messagebox.showinfo("Succès", "Gérer Votre stock Maintenant !", parent=self.window)
                    self.redirect_dashboard()
                    self.reset_fields()
                    con.close()

            except Exception as e:
                messagebox.showerror("Erreur!", f"Erreur due à {str(e)}", parent=self.window)

    def redirect_dashboard(self):
        self.window.destroy()
        dashboard_window = Tk()
        dashboard_obj = Interface(dashboard_window)
        dashboard_window.mainloop()

    def redirect_window(self):
        self.window.destroy()
        root = Tk()
        obj = SignUp(root)
        root.mainloop()



    def reset_fields(self):
        self.email_entry.delete(0, END)
        self.password_entry.delete(0, END)


if __name__ == "__main__":
    root = Tk()
    obj = login_page(root)
    root.mainloop()

